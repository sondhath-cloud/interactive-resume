# Card Effect | Swiper JS

A Pen created on CodePen.

Original URL: [https://codepen.io/ecemgo/pen/ZEVojzN](https://codepen.io/ecemgo/pen/ZEVojzN).

Note: Please do not use this on commercial platforms or projects without permission.