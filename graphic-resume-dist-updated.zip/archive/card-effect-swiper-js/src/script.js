var swiper = new Swiper(".swiper", {
    effect: "cards",
    cardsEffect: {
    rotate: true,
    },
    grabCursor: true,
    initialSlide: 2,
    speed: 500,
    loop: true,
    mousewheel: {
    invert: false,
  },
});