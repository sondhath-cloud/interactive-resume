# Text Scramble Effect

A Pen created on CodePen.

Original URL: [https://codepen.io/soulwire/pen/mEMPrK](https://codepen.io/soulwire/pen/mEMPrK).

A little text decoding / scramble effect